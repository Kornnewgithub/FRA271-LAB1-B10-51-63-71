/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Encoder_reader_simulink_private.h
 *
 * Code generated for Simulink model 'Encoder_reader_simulink'.
 *
 * Model version                  : 3.5
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Tue Oct 14 22:33:08 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Encoder_reader_simulink_private_h_
#define Encoder_reader_simulink_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "Encoder_reader_simulink.h"
#include "Encoder_reader_simulink_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

extern void Encode_DigitalPortRead_Init(DW_DigitalPortRead_Encoder_re_T *localDW);
extern void Encoder_rea_DigitalPortRead(B_DigitalPortRead_Encoder_rea_T *localB);
extern void Encoder__WrapAround_X1_Init(DW_WrapAround_X1_Encoder_read_T *localDW);
extern void Encoder_reade_WrapAround_X1(real_T rtu_curr, real_T *rty_position,
  DW_WrapAround_X1_Encoder_read_T *localDW);
extern void Encode_DigitalPortRead_Term(DW_DigitalPortRead_Encoder_re_T *localDW);

#endif                                 /* Encoder_reader_simulink_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
