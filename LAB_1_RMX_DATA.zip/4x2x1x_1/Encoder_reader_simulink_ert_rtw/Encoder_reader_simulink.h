/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Encoder_reader_simulink.h
 *
 * Code generated for Simulink model 'Encoder_reader_simulink'.
 *
 * Model version                  : 3.6
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Wed Oct 15 01:22:20 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Encoder_reader_simulink_h_
#define Encoder_reader_simulink_h_
#ifndef Encoder_reader_simulink_COMMON_INCLUDES_
#define Encoder_reader_simulink_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "math.h"
#include "main.h"
#include "mw_stm32_utils.h"
#endif                            /* Encoder_reader_simulink_COMMON_INCLUDES_ */

#include "Encoder_reader_simulink_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

/* Block signals for system '<S24>/Digital Port Read' */
typedef struct {
  boolean_T DigitalPortRead;           /* '<S24>/Digital Port Read' */
} B_DigitalPortRead_Encoder_rea_T;

/* Block states (default storage) for system '<S24>/Digital Port Read' */
typedef struct {
  stm32cube_blocks_DigitalPortR_T obj; /* '<S24>/Digital Port Read' */
  boolean_T objisempty;                /* '<S24>/Digital Port Read' */
} DW_DigitalPortRead_Encoder_re_T;

/* Block states (default storage) for system '<Root>/Homing Sequence' */
typedef struct {
  real_T offset;                       /* '<Root>/Homing Sequence' */
  int32_T sfEvent;                     /* '<Root>/Homing Sequence' */
  boolean_T doneDoubleBufferReInit;    /* '<Root>/Homing Sequence' */
  boolean_T offset_not_empty;          /* '<Root>/Homing Sequence' */
} DW_HomingSequence_Encoder_rea_T;

/* Block states (default storage) for system '<Root>/WrapAround _ X1' */
typedef struct {
  real_T last;                         /* '<Root>/WrapAround _ X1' */
  real_T offset;                       /* '<Root>/WrapAround _ X1' */
  int32_T sfEvent;                     /* '<Root>/WrapAround _ X1' */
  boolean_T doneDoubleBufferReInit;    /* '<Root>/WrapAround _ X1' */
  boolean_T last_not_empty;            /* '<Root>/WrapAround _ X1' */
  boolean_T offset_not_empty;          /* '<Root>/WrapAround _ X1' */
} DW_WrapAround_X1_Encoder_read_T;

/* Block signals (default storage) */
typedef struct {
  real_T uxDeg;                        /* '<Root>/1xDeg' */
  real_T uxRad;                        /* '<Root>/1xRad' */
  real_T uxDeg_c;                      /* '<Root>/2xDeg' */
  real_T uxRad_p;                      /* '<Root>/2xRad' */
  real_T uxDeg_h;                      /* '<Root>/4xDeg' */
  real_T uxRad_b;                      /* '<Root>/4xRad' */
  real_T position;                     /* '<Root>/WrapAround _ X4' */
  real_T position_g;                   /* '<Root>/WrapAround _ X2' */
  real_T position_e;                   /* '<Root>/WrapAround _ X1' */
  real_T w_deg;                        /* '<Root>/MATLAB Function5' */
  real_T a_deg;                        /* '<Root>/MATLAB Function5' */
  real_T w_rad;                        /* '<Root>/MATLAB Function4' */
  real_T a_rad;                        /* '<Root>/MATLAB Function4' */
  real_T w_deg_d;                      /* '<Root>/MATLAB Function3' */
  real_T a_deg_g;                      /* '<Root>/MATLAB Function3' */
  real_T w_rad_a;                      /* '<Root>/MATLAB Function2' */
  real_T a_rad_p;                      /* '<Root>/MATLAB Function2' */
  real_T w_deg_g;                      /* '<Root>/MATLAB Function1' */
  real_T a_deg_n;                      /* '<Root>/MATLAB Function1' */
  real_T w_rad_d;                      /* '<Root>/MATLAB Function' */
  real_T a_rad_pw;                     /* '<Root>/MATLAB Function' */
  uint32_T ux_Raw;                     /* '<Root>/4x_Raw' */
  uint32_T ux_Raw_o1;                  /* '<Root>/2x_Raw' */
  uint32_T ux_Raw_e;                   /* '<Root>/1x_Raw' */
  boolean_T DigitalPortRead;           /* '<S30>/Digital Port Read' */
  boolean_T DigitalPortRead_e;         /* '<S22>/Digital Port Read' */
  boolean_T DigitalPortRead_c4;        /* '<S20>/Digital Port Read' */
  B_DigitalPortRead_Encoder_rea_T DigitalPortRead_b;/* '<S24>/Digital Port Read' */
  B_DigitalPortRead_Encoder_rea_T DigitalPortRead_c;/* '<S24>/Digital Port Read' */
  B_DigitalPortRead_Encoder_rea_T DigitalPortRead_n;/* '<S24>/Digital Port Read' */
} B_Encoder_reader_simulink_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  stm32cube_blocks_EncoderBlock_T obj; /* '<Root>/4x_Raw' */
  stm32cube_blocks_EncoderBlock_T obj_l;/* '<Root>/2x_Raw' */
  stm32cube_blocks_EncoderBlock_T obj_j;/* '<Root>/1x_Raw' */
  stm32cube_blocks_DigitalPortR_T obj_g;/* '<S30>/Digital Port Read' */
  stm32cube_blocks_DigitalPortR_T obj_ja;/* '<S22>/Digital Port Read' */
  stm32cube_blocks_DigitalPortR_T obj_f;/* '<S20>/Digital Port Read' */
  real_T last_u;                       /* '<Root>/MATLAB Function5' */
  real_T last_w;                       /* '<Root>/MATLAB Function5' */
  real_T last_u_g;                     /* '<Root>/MATLAB Function4' */
  real_T last_w_n;                     /* '<Root>/MATLAB Function4' */
  real_T last_u_e;                     /* '<Root>/MATLAB Function3' */
  real_T last_w_k;                     /* '<Root>/MATLAB Function3' */
  real_T last_u_d;                     /* '<Root>/MATLAB Function2' */
  real_T last_w_g;                     /* '<Root>/MATLAB Function2' */
  real_T last_u_n;                     /* '<Root>/MATLAB Function1' */
  real_T last_w_l;                     /* '<Root>/MATLAB Function1' */
  real_T last_u_h;                     /* '<Root>/MATLAB Function' */
  real_T last_w_j;                     /* '<Root>/MATLAB Function' */
  real_T offset;                       /* '<Root>/Homing Sequence2' */
  boolean_T doneDoubleBufferReInit;    /* '<Root>/MATLAB Function5' */
  boolean_T last_u_not_empty;          /* '<Root>/MATLAB Function5' */
  boolean_T doneDoubleBufferReInit_o;  /* '<Root>/MATLAB Function4' */
  boolean_T last_u_not_empty_h;        /* '<Root>/MATLAB Function4' */
  boolean_T doneDoubleBufferReInit_i;  /* '<Root>/MATLAB Function3' */
  boolean_T last_u_not_empty_g;        /* '<Root>/MATLAB Function3' */
  boolean_T doneDoubleBufferReInit_m;  /* '<Root>/MATLAB Function2' */
  boolean_T last_u_not_empty_j;        /* '<Root>/MATLAB Function2' */
  boolean_T doneDoubleBufferReInit_ih; /* '<Root>/MATLAB Function1' */
  boolean_T last_u_not_empty_n;        /* '<Root>/MATLAB Function1' */
  boolean_T doneDoubleBufferReInit_p;  /* '<Root>/MATLAB Function' */
  boolean_T last_u_not_empty_e;        /* '<Root>/MATLAB Function' */
  boolean_T doneDoubleBufferReInit_c;  /* '<Root>/Homing Sequence2' */
  DW_WrapAround_X1_Encoder_read_T sf_WrapAround_X4;/* '<Root>/WrapAround _ X4' */
  DW_WrapAround_X1_Encoder_read_T sf_WrapAround_X2;/* '<Root>/WrapAround _ X2' */
  DW_WrapAround_X1_Encoder_read_T sf_WrapAround_X1;/* '<Root>/WrapAround _ X1' */
  DW_HomingSequence_Encoder_rea_T sf_HomingSequence1;/* '<Root>/Homing Sequence1' */
  DW_HomingSequence_Encoder_rea_T sf_HomingSequence;/* '<Root>/Homing Sequence' */
  DW_DigitalPortRead_Encoder_re_T DigitalPortRead_b;/* '<S24>/Digital Port Read' */
  DW_DigitalPortRead_Encoder_re_T DigitalPortRead_c;/* '<S24>/Digital Port Read' */
  DW_DigitalPortRead_Encoder_re_T DigitalPortRead_n;/* '<S24>/Digital Port Read' */
} DW_Encoder_reader_simulink_T;

/* Real-time Model Data Structure */
struct tag_RTM_Encoder_reader_simuli_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    struct {
      uint8_T TID[2];
    } TaskCounters;

    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block signals (default storage) */
extern B_Encoder_reader_simulink_T Encoder_reader_simulink_B;

/* Block states (default storage) */
extern DW_Encoder_reader_simulink_T Encoder_reader_simulink_DW;

/* External function called from main */
extern void Encoder_reader_simulink_SetEventsForThisBaseStep(boolean_T
  *eventFlags);

/* Model entry point functions */
extern void Encoder_reader_simulink_initialize(void);
extern void Encoder_reader_simulink_step0(void);/* Sample time: [0.001s, 0.0s] */
extern void Encoder_reader_simulink_step1(void);/* Sample time: [0.01s, 0.0s] */
extern void Encoder_reader_simulink_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Encoder_reader_simul_T *const Encoder_reader_simulink_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Encoder_reader_simulink'
 * '<S1>'   : 'Encoder_reader_simulink/A'
 * '<S2>'   : 'Encoder_reader_simulink/B'
 * '<S3>'   : 'Encoder_reader_simulink/H'
 * '<S4>'   : 'Encoder_reader_simulink/H1'
 * '<S5>'   : 'Encoder_reader_simulink/H2'
 * '<S6>'   : 'Encoder_reader_simulink/Homing Sequence'
 * '<S7>'   : 'Encoder_reader_simulink/Homing Sequence1'
 * '<S8>'   : 'Encoder_reader_simulink/Homing Sequence2'
 * '<S9>'   : 'Encoder_reader_simulink/MATLAB Function'
 * '<S10>'  : 'Encoder_reader_simulink/MATLAB Function1'
 * '<S11>'  : 'Encoder_reader_simulink/MATLAB Function2'
 * '<S12>'  : 'Encoder_reader_simulink/MATLAB Function3'
 * '<S13>'  : 'Encoder_reader_simulink/MATLAB Function4'
 * '<S14>'  : 'Encoder_reader_simulink/MATLAB Function5'
 * '<S15>'  : 'Encoder_reader_simulink/WrapAround _ X1'
 * '<S16>'  : 'Encoder_reader_simulink/WrapAround _ X2'
 * '<S17>'  : 'Encoder_reader_simulink/WrapAround _ X4'
 * '<S18>'  : 'Encoder_reader_simulink/X'
 * '<S19>'  : 'Encoder_reader_simulink/A/ECSoC'
 * '<S20>'  : 'Encoder_reader_simulink/A/ECSoC/ECSimCodegen'
 * '<S21>'  : 'Encoder_reader_simulink/B/ECSoC'
 * '<S22>'  : 'Encoder_reader_simulink/B/ECSoC/ECSimCodegen'
 * '<S23>'  : 'Encoder_reader_simulink/H/ECSoC'
 * '<S24>'  : 'Encoder_reader_simulink/H/ECSoC/ECSimCodegen'
 * '<S25>'  : 'Encoder_reader_simulink/H1/ECSoC'
 * '<S26>'  : 'Encoder_reader_simulink/H1/ECSoC/ECSimCodegen'
 * '<S27>'  : 'Encoder_reader_simulink/H2/ECSoC'
 * '<S28>'  : 'Encoder_reader_simulink/H2/ECSoC/ECSimCodegen'
 * '<S29>'  : 'Encoder_reader_simulink/X/ECSoC'
 * '<S30>'  : 'Encoder_reader_simulink/X/ECSoC/ECSimCodegen'
 */
#endif                                 /* Encoder_reader_simulink_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
