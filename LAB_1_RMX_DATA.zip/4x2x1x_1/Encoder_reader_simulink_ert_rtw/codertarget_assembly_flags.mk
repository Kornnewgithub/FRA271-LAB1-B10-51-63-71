ASFLAGS_ADDITIONAL = -mcpu=cortex-m4 -mthumb -mlittle-endian -mthumb-interwork -mfpu=fpv4-sp-d16 -mfloat-abi=hard
TARGET_LOAD_CMD = 
TARGET_LOAD_CMD_ARGS = 
TARGET_PKG_INSTALLDIR = C:/PROGRA~3/MATLAB/SUPPOR~1/R2025b_1/toolbox/target/SUPPOR~1/stm32/STM32G~1
STACK_SIZE = 512
