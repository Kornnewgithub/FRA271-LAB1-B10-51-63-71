/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Encoder_reader_simulink.c
 *
 * Code generated for Simulink model 'Encoder_reader_simulink'.
 *
 * Model version                  : 3.6
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Wed Oct 15 01:22:20 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Encoder_reader_simulink.h"
#include "rtwtypes.h"
#include "Encoder_reader_simulink_types.h"
#include "Encoder_reader_simulink_private.h"
#include <math.h>
#include "stm_timer_ll.h"

/* Named constants for MATLAB Function: '<Root>/Homing Sequence' */
#define Encoder_reader_simul_CALL_EVENT (-1)

/* Named constants for MATLAB Function: '<Root>/WrapAround _ X1' */
#define Encoder_reader_sim_CALL_EVENT_f (-1)

/* Block signals (default storage) */
B_Encoder_reader_simulink_T Encoder_reader_simulink_B;

/* Block states (default storage) */
DW_Encoder_reader_simulink_T Encoder_reader_simulink_DW;

/* Real-time model */
static RT_MODEL_Encoder_reader_simul_T Encoder_reader_simulink_M_;
RT_MODEL_Encoder_reader_simul_T *const Encoder_reader_simulink_M =
  &Encoder_reader_simulink_M_;

/* Forward declaration for local functions */
static void Encoder_reader_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj);
static void Encoder_read_SystemCore_setup_j(stm32cube_blocks_EncoderBlock_T *obj);
static void Encoder_rea_SystemCore_setup_j2(stm32cube_blocks_EncoderBlock_T *obj);
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to remember which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void Encoder_reader_simulink_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(Encoder_reader_simulink_M, 1));
}

/*
 *         This function updates active task flag for each subrate
 *         and rate transition flags for tasks that exchange data.
 *         The function assumes rate-monotonic multitasking scheduler.
 *         The function must be called at model base rate so that
 *         the generated code self-manages all its subrates and rate
 *         transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (Encoder_reader_simulink_M->Timing.TaskCounters.TID[1])++;
  if ((Encoder_reader_simulink_M->Timing.TaskCounters.TID[1]) > 9) {/* Sample time: [0.01s, 0.0s] */
    Encoder_reader_simulink_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* System initialize for atomic system: */
void Encode_DigitalPortRead_Init(DW_DigitalPortRead_Encoder_re_T *localDW)
{
  /* Start for MATLABSystem: '<S24>/Digital Port Read' */
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  localDW->obj.isInitialized = 1;
  localDW->obj.isSetupComplete = true;
}

/* Output and update for atomic system: */
void Encoder_rea_DigitalPortRead(B_DigitalPortRead_Encoder_rea_T *localB)
{
  uint32_T pinReadLoc;

  /* MATLABSystem: '<S24>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S24>/Digital Port Read' */
  localB->DigitalPortRead = ((pinReadLoc & 8192U) != 0U);
}

/* Termination for atomic system: */
void Encode_DigitalPortRead_Term(DW_DigitalPortRead_Encoder_re_T *localDW)
{
  /* Terminate for MATLABSystem: '<S24>/Digital Port Read' */
  if (!localDW->obj.matlabCodegenIsDeleted) {
    localDW->obj.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S24>/Digital Port Read' */
}

/*
 * System initialize for atomic system:
 *    '<Root>/Homing Sequence'
 *    '<Root>/Homing Sequence1'
 */
void Encoder_HomingSequence_Init(DW_HomingSequence_Encoder_rea_T *localDW)
{
  localDW->offset_not_empty = true;
  localDW->sfEvent = Encoder_reader_simul_CALL_EVENT;
}

/*
 * Output and update for atomic system:
 *    '<Root>/Homing Sequence'
 *    '<Root>/Homing Sequence1'
 */
void Encoder_read_HomingSequence(real_T rtu_pos, boolean_T rtu_trig, real_T
  *rty_Homing_position, DW_HomingSequence_Encoder_rea_T *localDW)
{
  localDW->sfEvent = Encoder_reader_simul_CALL_EVENT;
  if (rtu_trig) {
    localDW->offset = rtu_pos;
  }

  *rty_Homing_position = rtu_pos - localDW->offset;
}

/*
 * System initialize for atomic system:
 *    '<Root>/WrapAround _ X1'
 *    '<Root>/WrapAround _ X2'
 *    '<Root>/WrapAround _ X4'
 */
void Encoder__WrapAround_X1_Init(DW_WrapAround_X1_Encoder_read_T *localDW)
{
  localDW->sfEvent = Encoder_reader_sim_CALL_EVENT_f;
}

/*
 * Output and update for atomic system:
 *    '<Root>/WrapAround _ X1'
 *    '<Root>/WrapAround _ X2'
 *    '<Root>/WrapAround _ X4'
 */
void Encoder_reade_WrapAround_X1(real_T rtu_curr, real_T *rty_position,
  DW_WrapAround_X1_Encoder_read_T *localDW)
{
  real_T diff;
  localDW->sfEvent = Encoder_reader_sim_CALL_EVENT_f;
  if (!localDW->last_not_empty) {
    localDW->last = rtu_curr;
    localDW->last_not_empty = true;
    localDW->offset_not_empty = true;
  }

  diff = rtu_curr - localDW->last;
  if (diff > 30719.5) {
    localDW->offset -= 61440.0;
  } else if (diff < -30719.5) {
    localDW->offset += 61440.0;
  }

  *rty_position = rtu_curr + localDW->offset;
  localDW->last = rtu_curr;
}

static void Encoder_reader_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/1x_Raw' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM4;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/1x_Raw' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/1x_Raw' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/1x_Raw' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void Encoder_read_SystemCore_setup_j(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/2x_Raw' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM8;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/2x_Raw' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/2x_Raw' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/2x_Raw' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

static void Encoder_rea_SystemCore_setup_j2(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/4x_Raw' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM3;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/4x_Raw' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/4x_Raw' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/4x_Raw' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

/* Model step function for TID0 */
void Encoder_reader_simulink_step0(void) /* Sample time: [0.001s, 0.0s] */
{
  {                                    /* Sample time: [0.001s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  Encoder_reader_simulink_M->Timing.taskTime0 =
    ((time_T)(++Encoder_reader_simulink_M->Timing.clockTick0)) *
    Encoder_reader_simulink_M->Timing.stepSize0;
}

/* Model step function for TID1 */
void Encoder_reader_simulink_step1(void) /* Sample time: [0.01s, 0.0s] */
{
  real_T du;
  uint32_T pinReadLoc;

  /* MATLABSystem: '<Root>/1x_Raw' */
  Encoder_reader_simulink_B.ux_Raw_e = getTimerCounterValueForG4
    (Encoder_reader_simulink_DW.obj_j.TimerHandle, false, NULL);
  Encoder_rea_DigitalPortRead(&Encoder_reader_simulink_B.DigitalPortRead_b);

  /* MATLAB Function: '<Root>/Homing Sequence2' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion2'
   */
  if (Encoder_reader_simulink_B.DigitalPortRead_b.DigitalPortRead) {
    Encoder_reader_simulink_DW.offset = Encoder_reader_simulink_B.ux_Raw_e;
  }

  /* MATLAB Function: '<Root>/WrapAround _ X1' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion2'
   *  MATLAB Function: '<Root>/Homing Sequence2'
   */
  Encoder_reade_WrapAround_X1((real_T)Encoder_reader_simulink_B.ux_Raw_e -
    Encoder_reader_simulink_DW.offset, &Encoder_reader_simulink_B.position_e,
    &Encoder_reader_simulink_DW.sf_WrapAround_X1);

  /* Gain: '<Root>/1xDeg' */
  Encoder_reader_simulink_B.uxDeg = 15.0 * Encoder_reader_simulink_B.position_e;

  /* Gain: '<Root>/1xRad' */
  Encoder_reader_simulink_B.uxRad = 0.26179938779914941 *
    Encoder_reader_simulink_B.position_e;

  /* MATLAB Function: '<Root>/MATLAB Function4' */
  if (!Encoder_reader_simulink_DW.last_u_not_empty_h) {
    Encoder_reader_simulink_DW.last_u_g = Encoder_reader_simulink_B.position_e;
    Encoder_reader_simulink_DW.last_u_not_empty_h = true;
  }

  du = Encoder_reader_simulink_B.position_e -
    Encoder_reader_simulink_DW.last_u_g;
  if (fabs(du) > 1.0) {
    du = 0.0;
  }

  du = du / 0.001 * 0.26179938779914941;
  Encoder_reader_simulink_B.w_rad = (Encoder_reader_simulink_DW.last_w_n - du) *
    0.96907242630481061 + du;
  Encoder_reader_simulink_B.a_rad = (Encoder_reader_simulink_B.w_rad -
    Encoder_reader_simulink_DW.last_w_n) / 0.001;
  Encoder_reader_simulink_DW.last_u_g = Encoder_reader_simulink_B.position_e;
  Encoder_reader_simulink_DW.last_w_n = Encoder_reader_simulink_B.w_rad;

  /* End of MATLAB Function: '<Root>/MATLAB Function4' */
  /* MATLAB Function: '<Root>/MATLAB Function5' */
  if (!Encoder_reader_simulink_DW.last_u_not_empty) {
    Encoder_reader_simulink_DW.last_u = Encoder_reader_simulink_B.position_e;
    Encoder_reader_simulink_DW.last_u_not_empty = true;
  }

  du = Encoder_reader_simulink_B.position_e - Encoder_reader_simulink_DW.last_u;
  if (fabs(du) > 15.0) {
    du = 0.0;
  }

  du = du / 0.001 * 15.0;
  Encoder_reader_simulink_B.w_deg = (Encoder_reader_simulink_DW.last_w - du) *
    0.93910136742429262 + du;
  Encoder_reader_simulink_B.a_deg = (Encoder_reader_simulink_B.w_deg -
    Encoder_reader_simulink_DW.last_w) / 0.001;
  Encoder_reader_simulink_DW.last_u = Encoder_reader_simulink_B.position_e;
  Encoder_reader_simulink_DW.last_w = Encoder_reader_simulink_B.w_deg;

  /* End of MATLAB Function: '<Root>/MATLAB Function5' */
  /* MATLABSystem: '<Root>/2x_Raw' */
  Encoder_reader_simulink_B.ux_Raw_o1 = getTimerCounterValueForG4
    (Encoder_reader_simulink_DW.obj_l.TimerHandle, false, NULL);

  /* MATLABSystem: '<Root>/2x_Raw' */
  ouputDirectionOfCounter(Encoder_reader_simulink_DW.obj_l.TimerHandle);
  Encoder_rea_DigitalPortRead(&Encoder_reader_simulink_B.DigitalPortRead_c);

  /* MATLAB Function: '<Root>/Homing Sequence1' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion3'
   */
  Encoder_read_HomingSequence((real_T)Encoder_reader_simulink_B.ux_Raw_o1,
    Encoder_reader_simulink_B.DigitalPortRead_c.DigitalPortRead, &du,
    &Encoder_reader_simulink_DW.sf_HomingSequence1);

  /* MATLAB Function: '<Root>/WrapAround _ X2' */
  Encoder_reade_WrapAround_X1(du, &Encoder_reader_simulink_B.position_g,
    &Encoder_reader_simulink_DW.sf_WrapAround_X2);

  /* Gain: '<Root>/2xDeg' */
  Encoder_reader_simulink_B.uxDeg_c = 7.5 * Encoder_reader_simulink_B.position_g;

  /* Gain: '<Root>/2xRad' */
  Encoder_reader_simulink_B.uxRad_p = 0.1308996938995747 *
    Encoder_reader_simulink_B.position_g;

  /* MATLAB Function: '<Root>/MATLAB Function2' */
  if (!Encoder_reader_simulink_DW.last_u_not_empty_j) {
    Encoder_reader_simulink_DW.last_u_d = Encoder_reader_simulink_B.position_g;
    Encoder_reader_simulink_DW.last_u_not_empty_j = true;
  }

  du = Encoder_reader_simulink_B.position_g -
    Encoder_reader_simulink_DW.last_u_d;
  if (fabs(du) > 2.0) {
    du = 0.0;
  }

  du = du / 0.001 * 0.1308996938995747;
  Encoder_reader_simulink_B.w_rad_a = (Encoder_reader_simulink_DW.last_w_g - du)
    * 0.96907242630481061 + du;
  Encoder_reader_simulink_B.a_rad_p = (Encoder_reader_simulink_B.w_rad_a -
    Encoder_reader_simulink_DW.last_w_g) / 0.001;
  Encoder_reader_simulink_DW.last_u_d = Encoder_reader_simulink_B.position_g;
  Encoder_reader_simulink_DW.last_w_g = Encoder_reader_simulink_B.w_rad_a;

  /* End of MATLAB Function: '<Root>/MATLAB Function2' */
  /* MATLAB Function: '<Root>/MATLAB Function3' */
  if (!Encoder_reader_simulink_DW.last_u_not_empty_g) {
    Encoder_reader_simulink_DW.last_u_e = Encoder_reader_simulink_B.position_g;
    Encoder_reader_simulink_DW.last_u_not_empty_g = true;
  }

  du = Encoder_reader_simulink_B.position_g -
    Encoder_reader_simulink_DW.last_u_e;
  if (fabs(du) > 10.0) {
    du = 0.0;
  }

  du = du / 0.001 * 7.5;
  Encoder_reader_simulink_B.w_deg_d = (Encoder_reader_simulink_DW.last_w_k - du)
    * 0.93910136742429262 + du;
  Encoder_reader_simulink_B.a_deg_g = (Encoder_reader_simulink_B.w_deg_d -
    Encoder_reader_simulink_DW.last_w_k) / 0.001;
  Encoder_reader_simulink_DW.last_u_e = Encoder_reader_simulink_B.position_g;
  Encoder_reader_simulink_DW.last_w_k = Encoder_reader_simulink_B.w_deg_d;

  /* End of MATLAB Function: '<Root>/MATLAB Function3' */
  /* MATLABSystem: '<Root>/4x_Raw' */
  Encoder_reader_simulink_B.ux_Raw = getTimerCounterValueForG4
    (Encoder_reader_simulink_DW.obj.TimerHandle, false, NULL);
  Encoder_rea_DigitalPortRead(&Encoder_reader_simulink_B.DigitalPortRead_n);

  /* MATLAB Function: '<Root>/Homing Sequence' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   */
  Encoder_read_HomingSequence((real_T)Encoder_reader_simulink_B.ux_Raw,
    Encoder_reader_simulink_B.DigitalPortRead_n.DigitalPortRead, &du,
    &Encoder_reader_simulink_DW.sf_HomingSequence);

  /* MATLAB Function: '<Root>/WrapAround _ X4' */
  Encoder_reade_WrapAround_X1(du, &Encoder_reader_simulink_B.position,
    &Encoder_reader_simulink_DW.sf_WrapAround_X4);

  /* Gain: '<Root>/4xDeg' */
  Encoder_reader_simulink_B.uxDeg_h = 3.75 * Encoder_reader_simulink_B.position;

  /* Gain: '<Root>/4xRad' */
  Encoder_reader_simulink_B.uxRad_b = 0.065449846949787352 *
    Encoder_reader_simulink_B.position;

  /* MATLAB Function: '<Root>/MATLAB Function1' */
  if (!Encoder_reader_simulink_DW.last_u_not_empty_n) {
    Encoder_reader_simulink_DW.last_u_n = Encoder_reader_simulink_B.position;
    Encoder_reader_simulink_DW.last_u_not_empty_n = true;
  }

  du = Encoder_reader_simulink_B.position - Encoder_reader_simulink_DW.last_u_n;
  if (fabs(du) > 5.0) {
    du = 0.0;
  }

  du = du / 0.001 * 3.75;
  Encoder_reader_simulink_B.w_deg_g = (Encoder_reader_simulink_DW.last_w_l - du)
    * 0.93910136742429262 + du;
  Encoder_reader_simulink_B.a_deg_n = (Encoder_reader_simulink_B.w_deg_g -
    Encoder_reader_simulink_DW.last_w_l) / 0.001;
  Encoder_reader_simulink_DW.last_u_n = Encoder_reader_simulink_B.position;
  Encoder_reader_simulink_DW.last_w_l = Encoder_reader_simulink_B.w_deg_g;

  /* End of MATLAB Function: '<Root>/MATLAB Function1' */
  /* MATLAB Function: '<Root>/MATLAB Function' */
  if (!Encoder_reader_simulink_DW.last_u_not_empty_e) {
    Encoder_reader_simulink_DW.last_u_h = Encoder_reader_simulink_B.position;
    Encoder_reader_simulink_DW.last_u_not_empty_e = true;
  }

  du = Encoder_reader_simulink_B.position - Encoder_reader_simulink_DW.last_u_h;
  if (fabs(du) > 4.0) {
    du = 0.0;
  }

  du = du / 0.001 * 0.065449846949787352;
  Encoder_reader_simulink_B.w_rad_d = (Encoder_reader_simulink_DW.last_w_j - du)
    * 0.96907242630481061 + du;
  Encoder_reader_simulink_B.a_rad_pw = (Encoder_reader_simulink_B.w_rad_d -
    Encoder_reader_simulink_DW.last_w_j) / 0.001;
  Encoder_reader_simulink_DW.last_u_h = Encoder_reader_simulink_B.position;
  Encoder_reader_simulink_DW.last_w_j = Encoder_reader_simulink_B.w_rad_d;

  /* End of MATLAB Function: '<Root>/MATLAB Function' */
  /* MATLABSystem: '<S20>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S20>/Digital Port Read' */
  Encoder_reader_simulink_B.DigitalPortRead_c4 = ((pinReadLoc & 256U) != 0U);

  /* MATLABSystem: '<S22>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S22>/Digital Port Read' */
  Encoder_reader_simulink_B.DigitalPortRead_e = ((pinReadLoc & 64U) != 0U);

  /* MATLABSystem: '<S30>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S30>/Digital Port Read' */
  Encoder_reader_simulink_B.DigitalPortRead = ((pinReadLoc & 512U) != 0U);

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.01, which is the step size
   * of the task. Size of "clockTick1" ensures timer will not overflow during the
   * application lifespan selected.
   */
  Encoder_reader_simulink_M->Timing.clockTick1++;
}

/* Model initialize function */
void Encoder_reader_simulink_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(Encoder_reader_simulink_M, -1);
  Encoder_reader_simulink_M->Timing.stepSize0 = 0.001;

  /* External mode info */
  Encoder_reader_simulink_M->Sizes.checksums[0] = (2094070375U);
  Encoder_reader_simulink_M->Sizes.checksums[1] = (1328731550U);
  Encoder_reader_simulink_M->Sizes.checksums[2] = (570205602U);
  Encoder_reader_simulink_M->Sizes.checksums[3] = (3217436640U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[22];
    Encoder_reader_simulink_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = &rtAlwaysEnabled;
    systemRan[12] = &rtAlwaysEnabled;
    systemRan[13] = &rtAlwaysEnabled;
    systemRan[14] = &rtAlwaysEnabled;
    systemRan[15] = &rtAlwaysEnabled;
    systemRan[16] = &rtAlwaysEnabled;
    systemRan[17] = &rtAlwaysEnabled;
    systemRan[18] = &rtAlwaysEnabled;
    systemRan[19] = &rtAlwaysEnabled;
    systemRan[20] = &rtAlwaysEnabled;
    systemRan[21] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Encoder_reader_simulink_M->extModeInfo,
      &Encoder_reader_simulink_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Encoder_reader_simulink_M->extModeInfo,
                        Encoder_reader_simulink_M->Sizes.checksums);
    rteiSetTPtr(Encoder_reader_simulink_M->extModeInfo, rtmGetTPtr
                (Encoder_reader_simulink_M));
  }

  /* SystemInitialize for MATLAB Function: '<Root>/WrapAround _ X1' */
  Encoder__WrapAround_X1_Init(&Encoder_reader_simulink_DW.sf_WrapAround_X1);

  /* SystemInitialize for MATLAB Function: '<Root>/Homing Sequence1' */
  Encoder_HomingSequence_Init(&Encoder_reader_simulink_DW.sf_HomingSequence1);

  /* SystemInitialize for MATLAB Function: '<Root>/WrapAround _ X2' */
  Encoder__WrapAround_X1_Init(&Encoder_reader_simulink_DW.sf_WrapAround_X2);

  /* SystemInitialize for MATLAB Function: '<Root>/Homing Sequence' */
  Encoder_HomingSequence_Init(&Encoder_reader_simulink_DW.sf_HomingSequence);

  /* SystemInitialize for MATLAB Function: '<Root>/WrapAround _ X4' */
  Encoder__WrapAround_X1_Init(&Encoder_reader_simulink_DW.sf_WrapAround_X4);

  /* Start for MATLABSystem: '<Root>/1x_Raw' */
  Encoder_reader_simulink_DW.obj_j.isInitialized = 0;
  Encoder_reader_simulink_DW.obj_j.matlabCodegenIsDeleted = false;
  Encoder_reader_SystemCore_setup(&Encoder_reader_simulink_DW.obj_j);
  Encode_DigitalPortRead_Init(&Encoder_reader_simulink_DW.DigitalPortRead_b);

  /* Start for MATLABSystem: '<Root>/2x_Raw' */
  Encoder_reader_simulink_DW.obj_l.isInitialized = 0;
  Encoder_reader_simulink_DW.obj_l.matlabCodegenIsDeleted = false;
  Encoder_read_SystemCore_setup_j(&Encoder_reader_simulink_DW.obj_l);
  Encode_DigitalPortRead_Init(&Encoder_reader_simulink_DW.DigitalPortRead_c);

  /* Start for MATLABSystem: '<Root>/4x_Raw' */
  Encoder_reader_simulink_DW.obj.isInitialized = 0;
  Encoder_reader_simulink_DW.obj.matlabCodegenIsDeleted = false;
  Encoder_rea_SystemCore_setup_j2(&Encoder_reader_simulink_DW.obj);
  Encode_DigitalPortRead_Init(&Encoder_reader_simulink_DW.DigitalPortRead_n);

  /* Start for MATLABSystem: '<S20>/Digital Port Read' */
  Encoder_reader_simulink_DW.obj_f.matlabCodegenIsDeleted = false;
  Encoder_reader_simulink_DW.obj_f.isInitialized = 1;
  Encoder_reader_simulink_DW.obj_f.isSetupComplete = true;

  /* Start for MATLABSystem: '<S22>/Digital Port Read' */
  Encoder_reader_simulink_DW.obj_ja.matlabCodegenIsDeleted = false;
  Encoder_reader_simulink_DW.obj_ja.isInitialized = 1;
  Encoder_reader_simulink_DW.obj_ja.isSetupComplete = true;

  /* Start for MATLABSystem: '<S30>/Digital Port Read' */
  Encoder_reader_simulink_DW.obj_g.matlabCodegenIsDeleted = false;
  Encoder_reader_simulink_DW.obj_g.isInitialized = 1;
  Encoder_reader_simulink_DW.obj_g.isSetupComplete = true;
}

/* Model terminate function */
void Encoder_reader_simulink_terminate(void)
{
  uint8_T ChannelInfo;

  /* Terminate for MATLABSystem: '<Root>/1x_Raw' */
  if (!Encoder_reader_simulink_DW.obj_j.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_j.matlabCodegenIsDeleted = true;
    if ((Encoder_reader_simulink_DW.obj_j.isInitialized == 1) &&
        Encoder_reader_simulink_DW.obj_j.isSetupComplete) {
      disableCounter(Encoder_reader_simulink_DW.obj_j.TimerHandle);
      disableTimerInterrupts(Encoder_reader_simulink_DW.obj_j.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(Encoder_reader_simulink_DW.obj_j.TimerHandle,
                           ChannelInfo);
      disableTimerChannel2(Encoder_reader_simulink_DW.obj_j.TimerHandle,
                           ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/1x_Raw' */
  Encode_DigitalPortRead_Term(&Encoder_reader_simulink_DW.DigitalPortRead_b);

  /* Terminate for MATLABSystem: '<Root>/2x_Raw' */
  if (!Encoder_reader_simulink_DW.obj_l.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_l.matlabCodegenIsDeleted = true;
    if ((Encoder_reader_simulink_DW.obj_l.isInitialized == 1) &&
        Encoder_reader_simulink_DW.obj_l.isSetupComplete) {
      disableCounter(Encoder_reader_simulink_DW.obj_l.TimerHandle);
      disableTimerInterrupts(Encoder_reader_simulink_DW.obj_l.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(Encoder_reader_simulink_DW.obj_l.TimerHandle,
                           ChannelInfo);
      disableTimerChannel2(Encoder_reader_simulink_DW.obj_l.TimerHandle,
                           ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/2x_Raw' */
  Encode_DigitalPortRead_Term(&Encoder_reader_simulink_DW.DigitalPortRead_c);

  /* Terminate for MATLABSystem: '<Root>/4x_Raw' */
  if (!Encoder_reader_simulink_DW.obj.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj.matlabCodegenIsDeleted = true;
    if ((Encoder_reader_simulink_DW.obj.isInitialized == 1) &&
        Encoder_reader_simulink_DW.obj.isSetupComplete) {
      disableCounter(Encoder_reader_simulink_DW.obj.TimerHandle);
      disableTimerInterrupts(Encoder_reader_simulink_DW.obj.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(Encoder_reader_simulink_DW.obj.TimerHandle,
                           ChannelInfo);
      disableTimerChannel2(Encoder_reader_simulink_DW.obj.TimerHandle,
                           ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/4x_Raw' */
  Encode_DigitalPortRead_Term(&Encoder_reader_simulink_DW.DigitalPortRead_n);

  /* Terminate for MATLABSystem: '<S20>/Digital Port Read' */
  if (!Encoder_reader_simulink_DW.obj_f.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_f.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S20>/Digital Port Read' */
  /* Terminate for MATLABSystem: '<S22>/Digital Port Read' */
  if (!Encoder_reader_simulink_DW.obj_ja.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_ja.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S22>/Digital Port Read' */
  /* Terminate for MATLABSystem: '<S30>/Digital Port Read' */
  if (!Encoder_reader_simulink_DW.obj_g.matlabCodegenIsDeleted) {
    Encoder_reader_simulink_DW.obj_g.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S30>/Digital Port Read' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
