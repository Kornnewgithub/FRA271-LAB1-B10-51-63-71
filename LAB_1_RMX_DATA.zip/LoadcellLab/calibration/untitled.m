% Data from calibration
V = [0.0688 0.1974 0.3262 0.4538 0.5786 0.7144 0.8508 0.9906 1.128 1.266 1.398 1.532 1.669 1.941 2.082 2.211 2.349 2.480 2.502 2.520];
W_real = 0.5:0.5:10;

% Fit linear model
p = polyfit(V, W_real, 1);
W_fit = polyval(p, V);

% Plot result
figure;
plot(V, W_real, 'bo-', 'LineWidth', 1.5, 'DisplayName', 'Measured Data');
hold on;
plot(V, W_fit, 'r--', 'LineWidth', 1.5, 'DisplayName', sprintf('Fit: y = %.3f x + %.3f', p(1), p(2)));
xlabel('Output Voltage (V)');
ylabel('Actual Weight (kg)');
title('Calibration Curve: Load Cell + INA125');
legend('Location', 'northwest');
grid on;
text(0.1, 8, sprintf('Gain = %.3f kg/V\nOffset = %.3f kg', p(1), p(2)), 'FontSize', 10);
