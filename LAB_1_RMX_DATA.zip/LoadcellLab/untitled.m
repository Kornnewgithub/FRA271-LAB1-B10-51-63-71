% กำหนดช่วงค่าความต้านทานของ Trimpot (โอห์ม)
R_G = linspace(100, 100e3, 1000);  % เริ่มจาก 100 Ω เพื่อหลีกเลี่ยงหารศูนย์

% คำนวณ Gain จากสมการ G = 4 + (60k / R_G)
G = 4 + (60e3 ./ R_G);

% พล็อตกราฟ
figure;
plot(R_G/1000, G, 'LineWidth', 2);
xlabel('R_{G} (k\Omega)');
ylabel('Gain (V/V)');
title('Relationship between Gain and Trimpot Resistance (INA125)');
grid on;

% แสดงค่า Gain สูงสุดและต่ำสุด
G_min = 4 + 60e3/100e3;
G_max = 4 + 60e3/100; % ถ้า R = 100 Ω
fprintf('Gain ต่ำสุด ≈ %.2f\n', G_min);
fprintf('Gain สูงสุด ≈ %.2f\n', G_max);
