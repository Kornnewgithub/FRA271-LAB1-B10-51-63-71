
clear; clc; close all;


load('A_CCW_3.mat');      % โหลดไฟล์ X1.mat, จะได้ตัวแปรชื่อ data
data_X1 = data;      % เปลี่ยนชื่อ data เป็น data_X1 ทันที

load('B_CCW_3.mat');      % โหลดไฟล์ X2.mat, จะได้ตัวแปรชื่อ data มาอีกครั้ง
data_X2 = data;      % เปลี่ยนชื่อ data ที่เพิ่งโหลดมาเป็น data_X2

%load('4x_sample_2.mat');      % โหลดไฟล์ X4.mat (สมมติว่าไฟล์ที่ 3 คือ X4)
%data_X4 = data;      % เปลี่ยนชื่อเป็น data_X4

% ตอนนี้เรามีตัวแปร 3 ตัวแยกกันชัดเจน: data_X1, data_X2, data_X4

% ===== พล็อต =====
figure;
hold on; % << สำคัญมาก: เปิดโหมดวาดกราฟทับกัน

% --- พล็อตกราฟแต่ละตัวแปร ---
% ใช้ตัวแปรที่ตั้งชื่อใหม่ในการพล็อต
plot(data_X1, 'r', 'LineWidth', 1.5); % พล็อต X1 (เส้นสีแดง)
plot(data_X2, 'g', 'LineWidth', 1.5); % พล็อต X2 (เส้นสีเขียว)
%plot(data_X4, 'b', 'LineWidth', 1.5); % พล็อต X4 (เส้นสีน้ำเงิน)

hold off; % ปิดโหมดวาดทับ

% --- การตั้งค่ากราฟ ---
xlabel('Time (s)');
ylabel('Data');
title('Phase Relationship of signal A, B');
grid on;
xlim([3, 4.5]); % ปรับช่วงเวลาได้ตามต้องการ

% --- เพิ่มคำอธิบายกราฟ (Legend) ---
legend(data_X1.Name ,data_X2.Name,'A','B');
ylim([-0.5,1.5])